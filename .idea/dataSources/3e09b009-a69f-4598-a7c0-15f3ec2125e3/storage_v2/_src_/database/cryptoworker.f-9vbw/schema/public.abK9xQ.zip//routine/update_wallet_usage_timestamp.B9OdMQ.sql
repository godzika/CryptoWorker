create function update_wallet_usage_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.last_used_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

alter function update_wallet_usage_timestamp() owner to doadmin;

