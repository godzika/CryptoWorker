create procedure update_transaction_status(IN p_internal_id uuid, IN p_status character varying, IN p_tx_hash character varying DEFAULT NULL::character varying, IN p_error_message text DEFAULT NULL::text)
    language plpgsql
as
$$
BEGIN
    UPDATE transactions
    SET
        status = p_status,
        tx_hash = COALESCE(p_tx_hash, tx_hash),
        error_message = COALESCE(p_error_message, error_message),
        updated_at = CURRENT_TIMESTAMP
    WHERE internal_id = p_internal_id;
END;
$$;

alter procedure update_transaction_status(uuid, varchar, varchar, text) owner to doadmin;

