create function select_hot_wallet(p_asset character varying, p_amount numeric)
    returns TABLE(wallet_id integer, address character varying, private_key_encrypted text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        hw.wallet_id,
        hw.address,
        hw.private_key_encrypted
    FROM hot_wallets hw
    WHERE
        hw.asset = p_asset
        AND hw.is_active = TRUE
        AND (hw.current_balance - p_amount) >= hw.min_balance_threshold
    ORDER BY hw.last_used_at ASC NULLS FIRST
    LIMIT 1;
END;
$$;

alter function select_hot_wallet(varchar, numeric) owner to doadmin;

