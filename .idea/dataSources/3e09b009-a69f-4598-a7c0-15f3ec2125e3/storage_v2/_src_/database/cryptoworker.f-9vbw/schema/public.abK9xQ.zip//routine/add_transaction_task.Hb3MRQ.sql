create procedure add_transaction_task(IN p_internal_id uuid, IN p_operation_type character varying, IN p_asset character varying, IN p_amount numeric, IN p_destination_address character varying, IN p_callback_url text)
    language sql
as
$$
    INSERT INTO transactions (
        internal_id, operation_type, asset, amount,
        destination_address, callback_url
    ) VALUES (
        p_internal_id, p_operation_type, p_asset, p_amount,
        p_destination_address, p_callback_url
    );
$$;

alter procedure add_transaction_task(uuid, varchar, varchar, numeric, varchar, text) owner to doadmin;

